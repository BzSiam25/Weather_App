package com.example.weather_app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    EditText etCityName;
    Button btnFetchWeather;
    TextView tvCity, tvTemperature, tvHumidity, tvDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //here is the initialize part

        etCityName = findViewById(R.id.etCityName);
        btnFetchWeather = findViewById(R.id.btnFetchWeather);
        tvCity = findViewById(R.id.tvCity);
        tvTemperature = findViewById(R.id.tvTemperature);
        tvHumidity = findViewById(R.id.tvHumidity);
        tvDescription = findViewById(R.id.tvDescription);

        //here is the button listener part

        btnFetchWeather.setOnClickListener(v -> fetchWeatherData());


    }

    private void fetchWeatherData() {
        String city = etCityName.getText().toString().trim();

        if (city.isEmpty()) {
            Toast.makeText(this, "Please enter the city name", Toast.LENGTH_SHORT).show();
            return;

        }
        String apikey = "500fc8e7ab51c1cca1d0f02d2bf044f8";
        String url = "https://api.openweathermap.org/data/2.5/weather?q=London&appid=500fc8e7ab51c1cca1d0f02d2bf044f8&units=metric";

        RequestQueue requestqueue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            // Get the city name
                            String cityName = response.getString("name");

                            // Get the main object
                            JSONObject main = response.getJSONObject("main");
                            String temperature = main.getString("temp") + "°C"; // Append °C
                            String humidity = main.getString("humidity") + "%"; // Append %

                            // Get the weather description
                            String description = response.getJSONArray("weather")
                                    .getJSONObject(0)
                                    .getString("description"); // Fixed spelling

                            // Update UI with the fetched data
                            tvCity.setText("City: " + cityName); // Added space
                            tvTemperature.setText("Temperature: " + temperature); // Added space
                            tvHumidity.setText("Humidity: " + humidity); // Added space
                            tvDescription.setText("Description: " + description); // Added space
                        } catch (JSONException e) {
                            // Handle JSON parsing errors
                            e.printStackTrace();
                            Toast.makeText(MainActivity.this, "Error parsing JSON data", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle API response errors
                        Toast.makeText(MainActivity.this, "Failed to get data. Please check your connection!", Toast.LENGTH_SHORT).show();
                    }
                }
        );

// Add the request to the RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(this); // Ensure RequestQueue is initialized
        requestQueue.add(jsonObjectRequest);
    }
}